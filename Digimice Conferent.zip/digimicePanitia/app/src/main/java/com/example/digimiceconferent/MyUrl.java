package com.example.digimiceconferent;

public class MyUrl {
    public static String URL = "http://192.168.3.10/myAPI/public";
//    public static String URL = "https://apidigimice.me";
}


