<h3>Selamat Datang {{$name}} di <a href="http://digimice.id">digiMICE</a></h3>
<p>
{{$body}}<br/>
{{$title ?? ''}}<br/>
{{$email ?? ''}}<br/>
{{$password ?? ''}}<br/>
{{$note ?? ''}}
</p>








