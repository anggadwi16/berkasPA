<h3>Selamat Datang <?php echo e($name); ?> di <a href="http://digimice.id">digiMICE</a></h3>
<p>
<?php echo e($body); ?><br/>
<?php echo e($title ?? ''); ?><br/>
<?php echo e($email ?? ''); ?><br/>
<?php echo e($password ?? ''); ?><br/>
<?php echo e($note ?? ''); ?>

</p>








<?php /**PATH C:\xampp\htdocs\myAPI\resources\views/email/mail.blade.php ENDPATH**/ ?>