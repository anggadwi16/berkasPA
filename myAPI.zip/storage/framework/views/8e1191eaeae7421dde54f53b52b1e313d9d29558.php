<h3>Hai <?php echo e($name); ?></h3>
<p><?php echo e($body); ?></p>
<?php /**PATH C:\xampp\htdocs\myAPI\resources\views/email/sukses.blade.php ENDPATH**/ ?>